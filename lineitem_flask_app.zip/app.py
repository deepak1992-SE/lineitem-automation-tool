
from flask import Flask, render_template, request, redirect, flash
import os
import csv
from werkzeug.utils import secure_filename
from dfp.create_line_items import create_line_items, create_line_item_config

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'csv'}

app = Flask(__name__)
app.secret_key = 'your-secret-key'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        order_id = request.form.get('order_id')
        lineitem_prefix = request.form.get('lineitem_prefix')
        base_cpm = float(request.form.get('base_cpm'))

        file = request.files.get('lineitem_csv')
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Read CSV and create line item configs
            line_items_to_create = []
            with open(filepath, 'r') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    name = f"{lineitem_prefix}_{row.get('suffix')}"
                    cpm_micro = int(float(row.get('cpm', base_cpm)) * 1_000_000)
                    config = create_line_item_config(
                        name=name,
                        order_id=int(order_id),
                        placement_ids=[],
                        ad_unit_ids=[row.get('ad_unit_id')],
                        cpm_micro_amount=cpm_micro,
                        sizes=[[int(x) for x in row.get('size', '300x250').split('x')]],
                        key_gen_obj=None
                    )
                    line_items_to_create.append(config)

            result_ids = create_line_items(line_items_to_create)
            flash(f"Successfully created {len(result_ids)} line items.")
            return redirect('/')

    return render_template('index.html')
